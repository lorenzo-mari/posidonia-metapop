clear variables
close all
clc

% parameters
sigma_max=0.94; % maximum shoot survival
delta_s=10^-2.9545; % intensity of density dependence on shoot survival
g0_max=1.3; % maximum rhizome formation rate
delta_g=10^-2.9545; % intensity of density dependence on rhizome formation
h0_max=0.099; % maximum fruit production rate
delta_f=10^-2.9545; % intensity of density dependence on fruit production
f0_max=0.70; % maximum germination probability
delta_h=0; % intensity of density dependence on germination
nyears=100; % simulation timespan (years)

% loading marine sector data
load sectors sectors
lon=sectors(:,1); % longitude
lat=sectors(:,2); % latitude
s=sectors(:,3); % suitability score 
a=sectors(:,4); % fraction of suitable area
clear sectors
nsectors=numel(s);

% loading average connectivity matrix
load pot_conn_mat_ave CM_ave

% simulation 
x=zeros(nsectors,nyears+1); % preallocating state variables
x(:,1)=1e3*rand(size(s)); % setting random initial conditions
for y=1:nyears
    S=s*sigma_max./(1+delta_s*x(:,y)).*x(:,y); % shoot survival
    G=s*g0_max./(1+delta_g*x(:,y)).*x(:,y); % rhizome formation
    H=(CM_ave'*sparse(diag(a))*(s*h0_max./(1+delta_h*x(:,y)).*x(:,y)))./a; % fruit production and dispersal
    F=s*f0_max./(1+delta_f*x(:,y)); % germination probability
    x(:,y+1)=S+G+H.*F; % metapop dynamics
end
TD=x(:,end).*a; % total density at equilibrium

% plotting
figure('renderer','Painters')
scatter(lon,lat,5,log10(TD),'filled')
clim([-2.5 3.5])
cbh=colorbar('YTick',-2:3,'YTickLabel',10.^(-2:3),'Location','south');
cbh.Title.String='Total density of {\itP. oceanica} at equilibrium (shoots m^{-2})';
axis equal
axis off